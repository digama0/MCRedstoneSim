Redstone Simulator

This program simulates the behavior of redstone
in Minecraft.

Controls:

Left click to erase tiles or activate switches.
Right click to place the active material on the map.
Middle click on torches or switches to change the
wall they are attached to.
Use the scroll wheel to select a material from the
palette.

Areas on screen:


TOP: Toolbar (left to right)

Save/Open: save and load .rdat files to keep designs
between runs of the program.

Time Control:
Tick - step forward in time by one "tick" - that is,
the time for a torch to turn on or off from its
previous state.
Play - tick continually (at 10 ticks per second)
Pause - stop simulation

Level control:
Press these buttons (or up and down arrow keys, or
W and S) to go through horizontal slices. Level 1 is
ground level.

Adjust Size:
These 12 buttons move each face of the cuboid region
in or out, creating more or less space to work in.
The circled dot is an arrow pointing at you, and the
circled plus is an arrow pointing away from you.
If you shrink the area where you have placed
components, the program will warn you, unless you hold
Shift while doing so.

Redstone counts:
Keep track of your materials budget. "Redstone" is
wire, and total represents how many redstone need to
be mined to complete the project.


CENTER: Main view

This is where you make your design. Use the controls
described earlier to draw.

Note that you actually view 2 layers at once: the
level stated in the toolbar, and the one above that.
this is so that you can see most 2D designs. See
Palette.


BOTTOM: Palette

Click on the buttons to select the active material,
or use the mouse wheel. From left to right, the
materials are:

Air: air over air
Block: air over block
Wire: air over wire (note that this will also place
                     a block below, if necessary)
Torch: air over torch (middle click to change orientation)
Switch: air over switch
Button: air over button (button lasts 10 ticks)
Wire over Block
Torch over Block
Switch over Block
Bridge: wire over block over wire (this is the only palette
  option that will change anything 2 levels above, but is
  provided for convenience in viewing and editing)
Block over Wire
Block over Torch
Block over Switch
Door: 2-high (unlike Minecraft, this door actually makes
  the right sounds for open and close, rather than random)

Note that not all (25) combinations of two materials
stacked are represented here. In these cases (like torch 
over air, switch over wire) only the bottom object
will be visible (although you can always use the level
up button to get a complete picture).

This is still very much a work in progress; please PM
or post to Baezon on the Minecraft Forum:

http://www.minecraftforum.net/

to report any behavior which does not match Minecraft
redstone, or any bugs, feature requests, or interface
ideas that might help me improve this work.
